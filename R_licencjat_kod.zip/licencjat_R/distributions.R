# rozkłady 
rweibull()
rgamma()
rlnorm()

invgamma::rinvgamma()
rmutil::rinvgauss()
ERPeq::rexpweibull()
ggamma::rggamma()
rmutil::rhjorth()
RelDists::rAddW()

